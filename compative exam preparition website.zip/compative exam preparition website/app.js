const questions = [
  {
    question: "Which Article of the Indian Constitution guarantees equality before the law?",
    options: ["Article 14", "Article 19", "Article 21", "Article 32"],
    answer: 0,
    explanation: "Article 14 guarantees equality before the law and equal protection of the laws to every person in India."
  },
  {
    question: "The idea of Fundamental Duties in the Indian Constitution was inspired by the Constitution of which country?",
    options: ["United Kingdom", "United States", "Former Soviet Union", "Ireland"],
    answer: 2,
    explanation: "The Fundamental Duties were inspired by the Constitution of the former Soviet Union and added by the 42nd Amendment."
  },
  {
    question: "Which writ is issued to produce a person who has been unlawfully detained?",
    options: ["Mandamus", "Habeas corpus", "Certiorari", "Quo warranto"],
    answer: 1,
    explanation: "Habeas corpus requires that a detained person be brought before a court so the legality of detention can be examined."
  }
];

const paperQuestions = [
  {
    exam: "UPSC CSE", topic: "Polity", label: "Constitution · practice set",
    question: "Which Article of the Indian Constitution guarantees equality before the law?",
    options: ["Article 14", "Article 19", "Article 21", "Article 32"], answer: 0,
    explanation: "Article 14 guarantees equality before the law and equal protection of the laws to every person in India."
  },
  {
    exam: "UPSC CSE", topic: "Polity", label: "Constitution · practice set",
    question: "Which writ may a court issue to require that a detained person be brought before it?",
    options: ["Mandamus", "Habeas corpus", "Certiorari", "Quo warranto"], answer: 1,
    explanation: "Habeas corpus asks the authority holding a person to bring them before the court so the legality of detention can be examined."
  },
  {
    exam: "UPSC CSE", topic: "Economy", label: "Economy · practice set",
    question: "Which institution is responsible for issuing most currency notes in India?",
    options: ["Reserve Bank of India", "NITI Aayog", "Finance Commission", "State Bank of India"], answer: 0,
    explanation: "The Reserve Bank of India issues banknotes in India, except the one-rupee note, which is issued by the Government of India."
  },
  {
    exam: "SSC CGL", topic: "Science", label: "General science · practice set",
    question: "What is the SI unit of electric current?",
    options: ["Volt", "Ohm", "Ampere", "Watt"], answer: 2,
    explanation: "The ampere (A) is the SI base unit of electric current."
  },
  {
    exam: "SSC CGL", topic: "Economy", label: "Quantitative aptitude · practice set",
    question: "A number is increased by 20% and then decreased by 20%. What is the net change?",
    options: ["No change", "4% decrease", "4% increase", "2% decrease"], answer: 1,
    explanation: "Starting from 100, a 20% increase gives 120. A 20% decrease of 120 gives 96, which is a net 4% decrease."
  },
  {
    exam: "SSC CGL", topic: "Polity", label: "Civics · practice set",
    question: "What is the minimum voting age for an Indian citizen in a general election?",
    options: ["16 years", "18 years", "21 years", "25 years"], answer: 1,
    explanation: "The 61st Constitutional Amendment lowered the voting age from 21 to 18 years."
  },
  {
    exam: "Banking PO", topic: "Economy", label: "Banking awareness · practice set",
    question: "What does repo rate broadly refer to?",
    options: ["The rate at which RBI lends short-term funds to banks", "The rate banks pay on savings accounts", "The rate of GST on banking services", "The exchange rate set by commercial banks"], answer: 0,
    explanation: "The repo rate is the policy rate at which the Reserve Bank lends short-term funds to banks against eligible securities."
  },
  {
    exam: "Banking PO", topic: "Science", label: "Reasoning · practice set",
    question: "If all roses are flowers and some flowers fade quickly, which conclusion is certain?",
    options: ["All roses fade quickly", "Some roses fade quickly", "All roses are flowers", "No flowers are roses"], answer: 2,
    explanation: "Only the first statement is guaranteed: all roses belong to the group of flowers. The second statement does not establish that any roses fade quickly."
  },
  {
    exam: "Banking PO", topic: "Polity", label: "Banking awareness · practice set",
    question: "Which body regulates monetary policy in India?",
    options: ["Reserve Bank of India", "SEBI", "NABARD", "IRDAI"], answer: 0,
    explanation: "The Reserve Bank of India is India's central bank and is responsible for formulating and implementing monetary policy."
  },
  {
    exam: "GATE", topic: "Science", label: "Computer science · practice set",
    question: "What is the time complexity of binary search on a sorted array of n items?",
    options: ["O(1)", "O(log n)", "O(n)", "O(n log n)"], answer: 1,
    explanation: "Binary search halves the remaining search interval at each step, so it takes O(log n) comparisons."
  },
  {
    exam: "GATE", topic: "Economy", label: "Engineering mathematics · practice set",
    question: "For a square matrix A, what condition guarantees that A has an inverse?",
    options: ["The trace is zero", "The determinant is nonzero", "Every entry is positive", "The matrix is symmetric"], answer: 1,
    explanation: "A square matrix is invertible exactly when its determinant is nonzero."
  },
  {
    exam: "GATE", topic: "Polity", label: "Computer science · practice set",
    question: "In a relation represented by a directed graph, what property does a self-loop at every vertex demonstrate?",
    options: ["Symmetry", "Transitivity", "Reflexivity", "Antisymmetry"], answer: 2,
    explanation: "A relation is reflexive when every element is related to itself; graphically, this is a self-loop at every vertex."
  },
  {
    exam: "NEET", topic: "Science", label: "Biology · practice set",
    question: "Which organelle is the primary site of aerobic cellular respiration?",
    options: ["Ribosome", "Mitochondrion", "Golgi apparatus", "Lysosome"], answer: 1,
    explanation: "Most stages of aerobic respiration in eukaryotic cells take place in the mitochondrion."
  },
  {
    exam: "NEET", topic: "Economy", label: "Physics · practice set",
    question: "What is the SI unit of force?",
    options: ["Joule", "Pascal", "Newton", "Watt"], answer: 2,
    explanation: "The newton (N) is the SI unit of force, equal to one kilogram metre per second squared."
  },
  {
    exam: "NEET", topic: "Polity", label: "Chemistry · practice set",
    question: "At 25°C, what is the pH of a neutral aqueous solution?",
    options: ["0", "7", "10", "14"], answer: 1,
    explanation: "At 25°C, a neutral aqueous solution has pH 7, where hydrogen-ion and hydroxide-ion concentrations are equal."
  }
];

const storageKeys = {
  tasks: "orbit-study-tasks",
  exam: "orbit-target-exam",
  theme: "orbit-theme",
  questions: "orbit-question-count"
};
const defaultTasks = [
  { title: "Read: Fundamental Rights", category: "General studies", duration: "25 min", time: "9:00", done: true },
  { title: "Review yesterday’s notes", category: "Revision", duration: "15 min", time: "9:30", done: true },
  { title: "Practice: Polity quiz", category: "Practice", duration: "20 min", time: "11:00", done: false },
  { title: "Read daily current affairs", category: "Current affairs", duration: "20 min", time: "17:00", done: false }
];
let tasks = loadTasks();
let activeQuestion = 0;
let selectedAnswer = null;
let answered = false;
let toastTimer;
let signedInUser = null;
let activePaperTopic = "all";
let chatHistory = [];
let chatPending = false;

function loadTasks() {
  try {
    const stored = JSON.parse(localStorage.getItem(storageKeys.tasks));
    if (Array.isArray(stored) && stored.every((task) => task && typeof task.title === "string" && typeof task.done === "boolean")) return stored;
  } catch (error) {
    console.warn("Could not load the saved study plan.", error);
  }
  return defaultTasks.map((task) => ({ ...task }));
}

function saveTasks() {
  try {
    localStorage.setItem(storageKeys.tasks, JSON.stringify(tasks));
  } catch (error) {
    console.warn("Could not save the study plan.", error);
    showToast("Your browser could not save this change.");
  }
}

function showToast(message) {
  const toast = document.querySelector("#toast");
  toast.textContent = message;
  toast.classList.add("visible");
  window.clearTimeout(toastTimer);
  toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 2800);
}

function updateDate() {
  const now = new Date();
  const day = new Intl.DateTimeFormat("en", { weekday: "long" }).format(now).toUpperCase();
  document.querySelector("#current-date").textContent = `YOUR ${day}, AT A GLANCE`;
}

function updatePlan() {
  const list = document.querySelector("#plan-tasks");
  list.replaceChildren();
  tasks.forEach((task, index) => {
    const label = document.createElement("label");
    label.className = `plan-task${task.done ? " completed" : ""}`;
    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = task.done;
    checkbox.setAttribute("aria-label", `${task.done ? "Mark incomplete" : "Complete"}: ${task.title}`);
    checkbox.addEventListener("change", () => {
      tasks[index].done = checkbox.checked;
      saveTasks();
      updatePlan();
    });
    const check = document.createElement("span");
    check.className = "custom-check";
    check.textContent = task.done ? "✓" : "";
    const copy = document.createElement("span");
    copy.className = "task-copy";
    const title = document.createElement("strong");
    title.textContent = task.title;
    const details = document.createElement("small");
    details.textContent = `${task.category} · ${task.duration}`;
    copy.append(title, details);
    const time = document.createElement("span");
    time.className = "task-time";
    time.textContent = task.time;
    label.append(checkbox, check, copy, time);
    list.append(label);
  });
  const done = tasks.filter((task) => task.done).length;
  const percentage = tasks.length ? Math.round((done / tasks.length) * 100) : 0;
  document.querySelector("#plan-progress-text").textContent = `${done} of ${tasks.length} completed`;
  document.querySelector("#plan-progress-percent").textContent = `${percentage}%`;
  document.querySelector("#plan-progress-bar").style.width = `${percentage}%`;
}

function updateExam(exam) {
  const examDates = { "UPSC CSE": 124, "SSC CGL": 86, "Banking PO": 57, GATE: 103, NEET: 151 };
  document.querySelector("#exam-days").textContent = examDates[exam] || 124;
  document.querySelector("#exam-name-label").textContent = exam === "UPSC CSE" ? `${exam} • Prelims` : exam;
}

function selectExam(exam, notify = true) {
  document.querySelector("#exam-select").value = exam;
  document.querySelector("#paper-exam").value = exam;
  activePaperTopic = "all";
  document.querySelectorAll(".paper-tab").forEach((tab) => tab.classList.toggle("active", tab.dataset.paperFilter === "all"));
  updateExam(exam);
  renderPaperQuestions();
  try {
    localStorage.setItem(storageKeys.exam, exam);
  } catch (error) {
    console.warn("Could not save the target exam.", error);
  }
  if (notify) showToast(`Your dashboard is now set for ${exam}.`);
}

function openQuiz() {
  activeQuestion = 0;
  renderQuestion();
  document.querySelector("#quiz-modal").hidden = false;
  document.querySelector("#quiz-modal .modal-close").focus();
}

function closeQuiz() {
  document.querySelector("#quiz-modal").hidden = true;
}

function renderQuestion() {
  const question = questions[activeQuestion];
  selectedAnswer = null;
  answered = false;
  document.querySelector("#quiz-progress").textContent = `QUESTION ${activeQuestion + 1} OF ${questions.length}`;
  document.querySelector("#quiz-progress-bar").style.width = `${((activeQuestion + 1) / questions.length) * 100}%`;
  document.querySelector("#quiz-title").textContent = question.question;
  document.querySelector("#quiz-feedback").textContent = "";
  document.querySelector("#quiz-submit").hidden = false;
  document.querySelector("#quiz-submit").disabled = true;
  document.querySelector("#quiz-next").hidden = true;
  const options = document.querySelector("#quiz-options");
  options.replaceChildren();
  question.options.forEach((option, index) => {
    const button = document.createElement("button");
    button.className = "quiz-option";
    button.type = "button";
    const letter = document.createElement("span");
    letter.className = "option-letter";
    letter.textContent = String.fromCharCode(65 + index);
    const text = document.createElement("span");
    text.textContent = option;
    button.append(letter, text);
    button.addEventListener("click", () => {
      if (answered) return;
      selectedAnswer = index;
      options.querySelectorAll(".quiz-option").forEach((item) => item.classList.remove("selected"));
      button.classList.add("selected");
      document.querySelector("#quiz-submit").disabled = false;
    });
    options.append(button);
  });
}

function checkAnswer() {
  if (selectedAnswer === null || answered) return;
  answered = true;
  const question = questions[activeQuestion];
  const optionButtons = document.querySelectorAll(".quiz-option");
  optionButtons[question.answer].classList.add("correct");
  if (selectedAnswer !== question.answer) optionButtons[selectedAnswer].classList.add("incorrect");
  document.querySelector("#quiz-feedback").textContent = `${selectedAnswer === question.answer ? "Correct! " : "Not quite. "}${question.explanation}`;
  document.querySelector("#quiz-submit").hidden = true;
  const next = document.querySelector("#quiz-next");
  next.hidden = false;
  next.textContent = activeQuestion === questions.length - 1 ? "Finish practice ✓" : "Next question →";
}

function advanceQuestion() {
  if (activeQuestion < questions.length - 1) {
    activeQuestion += 1;
    renderQuestion();
    return;
  }
  const count = Number(localStorage.getItem(storageKeys.questions) || "248") + questions.length;
  localStorage.setItem(storageKeys.questions, String(count));
  document.querySelector("#question-count").textContent = count;
  closeQuiz();
  showToast("Practice complete! Your progress has been updated.");
}

function addTask() {
  const title = window.prompt("What would you like to study?");
  if (title === null) return;
  const cleanTitle = title.trim();
  if (!cleanTitle) {
    showToast("Enter a task name to add it to your plan.");
    return;
  }
  tasks.push({ title: cleanTitle.slice(0, 60), category: "Study session", duration: "25 min", time: "Anytime", done: false });
  saveTasks();
  updatePlan();
}

function addChatMessage(text, fromUser) {
  const message = document.createElement("div");
  message.className = `chat-message${fromUser ? " user-message" : " bot-message"}`;
  if (!fromUser) {
    const avatar = document.createElement("span");
    avatar.className = "message-avatar";
    avatar.textContent = "✦";
    message.append(avatar);
  }
  const paragraph = document.createElement("p");
  paragraph.textContent = text;
  message.append(paragraph);
  const messages = document.querySelector("#chat-messages");
  messages.append(message);
  messages.scrollTop = messages.scrollHeight;
  return message;
}

async function readApiJson(response, endpoint) {
  const contentType = response.headers.get("content-type") || "";
  if (!contentType.toLowerCase().includes("application/json")) {
    if (response.status === 403) {
      throw new Error(`${endpoint} was blocked (403 Forbidden). Start server.py and open http://127.0.0.1:8000, or configure your host to allow the /api endpoint.`);
    }
    if (!response.ok) throw new Error(`${endpoint} failed (${response.status}). Check the server and hosting configuration.`);
    throw new Error(`${endpoint} returned a non-JSON response. Open the dashboard through server.py and check that /api routes reach the Python server.`);
  }
  try {
    return await response.json();
  } catch {
    throw new Error(`${endpoint} returned invalid JSON. Restart server.py and check for a proxy or hosting rule blocking /api requests.`);
  }
}

async function submitTutorPrompt(prompt) {
  const text = prompt.trim();
  if (!text || chatPending) return;
  chatPending = true;
  const input = document.querySelector("#chat-input");
  const submitButton = document.querySelector("#chat-form button[type=submit]");
  input.disabled = true;
  submitButton.disabled = true;
  addChatMessage(text, true);
  chatHistory.push({ role: "user", content: text });
  chatHistory = chatHistory.slice(-12);
  const loadingMessage = addChatMessage("Thinking…", false);
  loadingMessage.classList.add("chat-loading");

  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ messages: chatHistory })
    });
    const result = await readApiJson(response, "The AI chat endpoint");
    if (!response.ok) throw new Error(result.error || `AI request failed (${response.status}).`);
    if (typeof result.answer !== "string" || !result.answer.trim()) throw new Error("The AI returned an empty answer. Please try again.");
    chatHistory.push({ role: "assistant", content: result.answer });
    chatHistory = chatHistory.slice(-12);
    loadingMessage.remove();
    addChatMessage(result.answer, false);
  } catch (error) {
    loadingMessage.remove();
    const message = error instanceof Error ? error.message : "The AI request failed. Please try again.";
    addChatMessage(message, false);
  } finally {
    chatPending = false;
    input.disabled = false;
    submitButton.disabled = false;
    input.focus();
  }
}

async function checkAiStatus() {
  const status = document.querySelector("#ai-status");
  const dot = document.querySelector("#ai-status-dot");
  try {
    const response = await fetch("/api/health");
    if (!response.ok) throw new Error(`AI status request failed (${response.status}).`);
    const result = await readApiJson(response, "The AI status endpoint");
    if (typeof result.configured !== "boolean" || typeof result.model !== "string") {
      throw new Error("The AI status endpoint returned an unexpected response.");
    }
    status.textContent = result.configured ? `Live AI ready · ${result.model}` : "AI key needed · see setup";
    status.title = result.configured
      ? `Connected to ${result.model}.`
      : "Copy .env.example to .env and add your provider API key, then refresh the dashboard. Never share your key.";
    dot.classList.toggle("ai-live", result.configured);
    dot.classList.toggle("ai-offline", !result.configured);
  } catch (error) {
    status.textContent = error instanceof Error && error.message.includes("403") ? "AI endpoint blocked · check server setup" : "Server unavailable · start server.py";
    status.title = error instanceof Error ? error.message : "The AI server could not be reached.";
    dot.classList.remove("ai-live");
    dot.classList.add("ai-offline");
  }
}

function sendChatMessage(event) {
  event.preventDefault();
  const input = document.querySelector("#chat-input");
  const text = input.value.trim();
  if (!text || chatPending) return;
  input.value = "";
  void submitTutorPrompt(text);
}

function renderPaperQuestions() {
  const exam = document.querySelector("#paper-exam").value;
  const visibleQuestions = paperQuestions.filter((item) => item.exam === exam && (activePaperTopic === "all" || item.topic === activePaperTopic));
  const list = document.querySelector("#paper-list");
  list.replaceChildren();
  document.querySelector("#paper-count").textContent = `${visibleQuestions.length} ${visibleQuestions.length === 1 ? "question" : "questions"}`;
  if (!visibleQuestions.length) {
    const empty = document.createElement("p");
    empty.className = "paper-empty";
    empty.textContent = "No questions in this topic yet. Choose another topic to continue.";
    list.append(empty);
    return;
  }
  visibleQuestions.forEach((item, index) => {
    const article = document.createElement("article");
    article.className = "paper-question";
    const heading = document.createElement("div");
    heading.className = "paper-question-heading";
    const meta = document.createElement("div");
    meta.className = "paper-meta";
    const topic = document.createElement("span");
    topic.className = "tag tag-purple";
    topic.textContent = item.topic.toUpperCase();
    const label = document.createElement("span");
    label.textContent = item.label;
    meta.append(topic, label);
    const indexLabel = document.createElement("span");
    indexLabel.className = "paper-index";
    indexLabel.textContent = `Q${index + 1}`;
    heading.append(meta, indexLabel);
    const question = document.createElement("h3");
    question.textContent = item.question;
    const answers = document.createElement("div");
    answers.className = "paper-options";
    item.options.forEach((option, optionIndex) => {
      const optionElement = document.createElement("span");
      optionElement.className = "paper-option";
      optionElement.textContent = `${String.fromCharCode(65 + optionIndex)}. ${option}`;
      answers.append(optionElement);
    });
    const actions = document.createElement("div");
    actions.className = "paper-actions";
    const answerButton = document.createElement("button");
    answerButton.className = "subtle-button paper-answer-toggle";
    answerButton.type = "button";
    answerButton.textContent = "Show answer";
    const botButton = document.createElement("button");
    botButton.className = "subtle-button paper-bot-button";
    botButton.type = "button";
    botButton.textContent = "✦ Explain with bot";
    actions.append(answerButton, botButton);
    const answer = document.createElement("div");
    answer.className = "paper-answer";
    answer.hidden = true;
    const answerText = document.createElement("strong");
    answerText.textContent = `Answer: ${String.fromCharCode(65 + item.answer)}. ${item.options[item.answer]}`;
    const explanation = document.createElement("p");
    explanation.textContent = item.explanation;
    answer.append(answerText, explanation);
    answerButton.addEventListener("click", () => {
      answer.hidden = !answer.hidden;
      answerButton.textContent = answer.hidden ? "Show answer" : "Hide answer";
    });
    botButton.addEventListener("click", () => {
      void submitTutorPrompt(`Please explain: ${item.question}`);
      document.querySelector("#chat-messages").scrollIntoView({ behavior: "smooth", block: "center" });
    });
    article.append(heading, question, answers, actions, answer);
    list.append(article);
  });
}

function openLogin() {
  if (signedInUser) {
    signedInUser = null;
    updateSignedInState();
    showToast("You’ve signed out of this preview session.");
    return;
  }
  document.querySelector("#login-modal").hidden = false;
  document.querySelector("#login-email").focus();
}

function updateSignedInState() {
  const name = signedInUser ? signedInUser.name : "Guest learner";
  document.querySelector("#profile-name").textContent = name;
  document.querySelector("#profile-status").textContent = signedInUser ? "Preview session" : "Sign in to personalize";
  document.querySelector("#greeting-name").textContent = signedInUser ? `, ${name.split(/\s+/)[0]}` : ", learner";
  document.querySelector("#login-button").textContent = signedInUser ? "Sign out" : "Sign in";
  document.querySelector("#profile-button").setAttribute("aria-label", signedInUser ? "Sign out" : "Sign in");
  document.querySelector(".avatar").textContent = signedInUser ? name.trim().charAt(0).toUpperCase() : "G";
}

const searchableItems = [
  { title: "Indian Polity: Fundamental Rights", detail: "Today’s focus · General Studies", target: "#practice" },
  { title: "Polity: Chapter practice", detail: "Mock test · 20 questions", target: "#mock-tests" },
  { title: "Current affairs: October", detail: "Mock test · 15 questions", target: "#mock-tests" },
  { title: "Daily current affairs", detail: "Quick resource · Today’s 5-minute read", target: "#study-plan" },
  { title: "Polity revision notes", detail: "Quick resource · 12 key concepts", target: "#study-plan" },
  { title: "Previous year questions", detail: "Quick resource · Practice by topic", target: "#mock-tests" },
  { title: "Previous-year question practice", detail: "Practice bank · Filter by exam and topic", target: "#previous-papers" },
  { title: "Performance overview", detail: "Your learning journey", target: "#performance" },
  { title: "Today’s plan", detail: "Your study checklist", target: "#study-plan" }
];

function openSearch() {
  const overlay = document.querySelector("#search-overlay");
  overlay.hidden = false;
  document.querySelector("#global-search").focus();
}

function closeSearch() {
  document.querySelector("#search-overlay").hidden = true;
  document.querySelector("#global-search").value = "";
  renderSearchResults("");
}

function renderSearchResults(query) {
  const container = document.querySelector("#search-results");
  container.replaceChildren();
  const normalized = query.trim().toLowerCase();
  if (!normalized) {
    const hint = document.createElement("p");
    hint.textContent = "Try “polity”, “current affairs”, or “mock test”.";
    container.append(hint);
    return;
  }
  const results = searchableItems.filter((item) => `${item.title} ${item.detail}`.toLowerCase().includes(normalized));
  if (!results.length) {
    const empty = document.createElement("p");
    empty.textContent = "No matches yet. Try another topic or keyword.";
    container.append(empty);
    return;
  }
  results.forEach((result) => {
    const button = document.createElement("button");
    button.className = "search-result";
    button.type = "button";
    const title = document.createElement("strong");
    title.textContent = result.title;
    const detail = document.createElement("small");
    detail.textContent = result.detail;
    button.append(title, detail);
    button.addEventListener("click", () => {
      closeSearch();
      document.querySelector(result.target).scrollIntoView({ behavior: "smooth" });
    });
    container.append(button);
  });
}

document.querySelectorAll("[data-open-quiz]").forEach((button) => button.addEventListener("click", openQuiz));
document.querySelectorAll("[data-scroll]").forEach((button) => button.addEventListener("click", () => {
  document.querySelector(`#${button.dataset.scroll}`).scrollIntoView({ behavior: "smooth" });
}));
document.querySelector(".modal-close").addEventListener("click", closeQuiz);
document.querySelector("#quiz-modal").addEventListener("click", (event) => {
  if (event.target.id === "quiz-modal") closeQuiz();
});
document.querySelector("#quiz-submit").addEventListener("click", checkAnswer);
document.querySelector("#quiz-next").addEventListener("click", advanceQuestion);
document.querySelector("#add-task").addEventListener("click", addTask);
document.querySelector("#chat-form").addEventListener("submit", sendChatMessage);
document.querySelector("#paper-exam").addEventListener("change", (event) => selectExam(event.target.value));
document.querySelectorAll(".paper-tab").forEach((button) => button.addEventListener("click", () => {
  activePaperTopic = button.dataset.paperFilter;
  document.querySelectorAll(".paper-tab").forEach((tab) => tab.classList.toggle("active", tab === button));
  renderPaperQuestions();
}));
document.querySelectorAll("[data-ask]").forEach((button) => button.addEventListener("click", () => {
  void submitTutorPrompt(button.dataset.ask);
}));
document.querySelector("#login-button").addEventListener("click", openLogin);
document.querySelector("#profile-button").addEventListener("click", openLogin);
document.querySelector("#login-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const email = document.querySelector("#login-email").value.trim();
  const name = document.querySelector("#login-display-name").value.trim();
  if (!email || !name) return;
  signedInUser = { email, name };
  updateSignedInState();
  document.querySelector("#login-modal").hidden = true;
  event.currentTarget.reset();
  showToast(`Welcome, ${name.split(/\s+/)[0]}! This preview session is active until you leave the page.`);
});
document.querySelector(".login-close").addEventListener("click", () => { document.querySelector("#login-modal").hidden = true; });
document.querySelector("#login-modal").addEventListener("click", (event) => {
  if (event.target.id === "login-modal") document.querySelector("#login-modal").hidden = true;
});
document.querySelector("#exam-select").addEventListener("change", (event) => selectExam(event.target.value));
document.querySelectorAll(".resource-link").forEach((button) => button.addEventListener("click", () => showToast(`${button.dataset.resource} is ready to explore in your learning library.`)));
document.querySelector(".theme-toggle").addEventListener("click", () => {
  document.body.classList.toggle("dark");
  const dark = document.body.classList.contains("dark");
  try { localStorage.setItem(storageKeys.theme, dark ? "dark" : "light"); } catch (error) { console.warn("Could not save the theme preference.", error); }
  document.querySelector(".theme-toggle").textContent = dark ? "☾" : "☼";
});
document.querySelector("#mobile-search").addEventListener("click", openSearch);
document.querySelector(".search-trigger").addEventListener("click", openSearch);
document.querySelector("#global-search").addEventListener("input", (event) => renderSearchResults(event.target.value));
document.querySelector("#search-overlay").addEventListener("click", (event) => {
  if (event.target.id === "search-overlay") closeSearch();
});
document.querySelector(".period-select").addEventListener("change", (event) => showToast(`Showing ${event.target.value.toLowerCase()} performance.`));
document.querySelector(".notification-button").addEventListener("click", () => showToast("You’re all caught up. Keep up your study streak!"));

document.querySelectorAll(".nav-item").forEach((link) => link.addEventListener("click", () => {
  document.querySelectorAll(".nav-item").forEach((item) => item.classList.remove("active"));
  link.classList.add("active");
}));

document.addEventListener("keydown", (event) => {
  if (event.key === "Escape") {
    closeQuiz();
    closeSearch();
  }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") {
    event.preventDefault();
    openSearch();
  }
});

updateDate();
updatePlan();
try {
  const savedExam = localStorage.getItem(storageKeys.exam);
  if (savedExam && [...document.querySelector("#exam-select").options].some((option) => option.value === savedExam)) {
    selectExam(savedExam, false);
  }
  if (localStorage.getItem(storageKeys.theme) === "dark") {
    document.body.classList.add("dark");
    document.querySelector(".theme-toggle").textContent = "☾";
  }
  const savedQuestionCount = localStorage.getItem(storageKeys.questions);
  if (savedQuestionCount && Number.isFinite(Number(savedQuestionCount))) document.querySelector("#question-count").textContent = savedQuestionCount;
} catch (error) {
  console.warn("Could not restore dashboard preferences.", error);
}
renderPaperQuestions();
void checkAiStatus();
