"""Local web server and server-side OpenAI-compatible chat proxy."""

from __future__ import annotations

import json
import os
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import unquote, urlsplit
from urllib.request import Request, urlopen


ROOT = Path(__file__).resolve().parent
PROCESS_ENV_KEYS = frozenset(key for key, value in os.environ.items() if value)
MAX_REQUEST_BYTES = 16_000
MAX_MESSAGES = 12
MAX_MESSAGE_CHARS = 1_200
MAX_TOTAL_CHARS = 10_000
MAX_PROVIDER_RESPONSE_BYTES = 1_000_000
SYSTEM_PROMPT = (
    "You are Competitive Exam's helpful tutor for competitive-exam students. "
    "Explain solutions step by step, distinguish facts from uncertainty, and "
    "never invent official exam answers or citations. If a question is ambiguous, "
    "ask a concise clarifying question. Encourage students to verify important "
    "facts with trusted, current study materials."
)


def load_local_env(env_file=None):
    """Load simple KEY=VALUE settings without overriding the shell environment."""
    if env_file is None:
        env_file = ROOT / ".env"
    if not env_file.is_file():
        return
    for line_number, raw_line in enumerate(env_file.read_text(encoding="utf-8").splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("export "):
            line = line[7:].lstrip()
        key, separator, value = line.partition("=")
        key = key.strip()
        if not separator or not key or not key.replace("_", "").isalnum() or key[0].isdigit():
            raise ValueError(f"Invalid setting in .env on line {line_number}. Expected KEY=VALUE.")
        value = value.strip()
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        if key not in PROCESS_ENV_KEYS:
            os.environ[key] = value


class CompetitiveExamHandler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self):
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        super().end_headers()

    def send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        request_path = unquote(urlsplit(self.path).path)
        if any(part == ".env" or part.startswith(".env.") for part in Path(request_path).parts):
            self.send_error(404, "Not found")
            return
        if request_path == "/api/health":
            try:
                load_local_env()
            except ValueError as error:
                self.send_json(500, {"error": str(error)})
                return
            self.send_json(
                200,
                {
                    "configured": bool(os.environ.get("OPENAI_API_KEY", "").strip()),
                    "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
                },
            )
            return
        super().do_GET()

    def do_POST(self):
        if urlsplit(self.path).path != "/api/chat":
            self.send_json(404, {"error": "Endpoint not found."})
            return

        content_type = self.headers.get("Content-Type", "")
        if not content_type.lower().startswith("application/json"):
            self.send_json(415, {"error": "Send the question as JSON."})
            return

        try:
            content_length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_json(400, {"error": "Invalid request length."})
            return
        if content_length <= 0 or content_length > MAX_REQUEST_BYTES:
            self.send_json(413, {"error": "The chat request is empty or too large."})
            return

        try:
            payload = json.loads(self.rfile.read(content_length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_json(400, {"error": "The chat request must contain valid JSON."})
            return

        messages = payload.get("messages") if isinstance(payload, dict) else None
        error = self.validate_messages(messages)
        if error:
            self.send_json(400, {"error": error})
            return

        try:
            load_local_env()
        except ValueError as error:
            self.send_json(500, {"error": str(error)})
            return

        api_key = os.environ.get("OPENAI_API_KEY", "").strip()
        if not api_key:
            self.send_json(
                503,
                {
                    "error": (
                        "Live AI needs a provider API key. Create a private .env file from .env.example, "
                        "add your key, then refresh this page. Never share the key in chat."
                    )
                },
            )
            return

        base_url = os.environ.get("OPENAI_BASE_URL", "https://api.openai.com/v1").strip().rstrip("/")
        parsed_url = urlsplit(base_url)
        if parsed_url.scheme not in ("http", "https") or not parsed_url.netloc:
            self.send_json(500, {"error": "OPENAI_BASE_URL must be a valid HTTP or HTTPS URL."})
            return
        endpoint = base_url if base_url.endswith("/chat/completions") else f"{base_url}/chat/completions"

        provider_payload = {
            "model": os.environ.get("OPENAI_MODEL", "gpt-4o-mini"),
            "messages": [{"role": "system", "content": SYSTEM_PROMPT}, *messages],
            "max_tokens": 700,
        }
        request = Request(
            endpoint,
            data=json.dumps(provider_payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )

        try:
            with urlopen(request, timeout=60) as response:
                raw_response = response.read(MAX_PROVIDER_RESPONSE_BYTES + 1)
            if len(raw_response) > MAX_PROVIDER_RESPONSE_BYTES:
                self.send_json(502, {"error": "The AI provider returned an oversized response."})
                return
            provider_response = json.loads(raw_response)
            answer = provider_response["choices"][0]["message"]["content"]
            if not isinstance(answer, str) or not answer.strip():
                raise ValueError("The provider returned no text answer.")
        except HTTPError as error:
            status = 503 if error.code == 429 else 502
            message = (
                "The AI provider is busy. Please try again shortly."
                if error.code == 429
                else "The AI provider rejected the request. Check the server key, model, and provider settings."
            )
            self.log_error("AI provider returned HTTP %s", error.code)
            self.send_json(status, {"error": message})
            return
        except (URLError, TimeoutError) as error:
            self.log_error("AI provider connection failed: %s", error)
            self.send_json(502, {"error": "Could not reach the AI provider. Check the server connection and try again."})
            return
        except (json.JSONDecodeError, KeyError, IndexError, TypeError, ValueError):
            self.log_error("AI provider returned an invalid response.")
            self.send_json(502, {"error": "The AI provider returned an invalid response. Please try again."})
            return

        self.send_json(200, {"answer": answer.strip()})

    @staticmethod
    def validate_messages(messages):
        if not isinstance(messages, list) or not messages or len(messages) > MAX_MESSAGES:
            return "Send between 1 and 12 chat messages."

        total_chars = 0
        for message in messages:
            if not isinstance(message, dict) or message.get("role") not in ("user", "assistant"):
                return "Chat messages must have a user or assistant role."
            content = message.get("content")
            if not isinstance(content, str) or not content.strip() or len(content) > MAX_MESSAGE_CHARS:
                return "Each chat message must contain 1 to 1,200 characters."
            total_chars += len(content)

        if total_chars > MAX_TOTAL_CHARS:
            return "The conversation is too long. Start a new chat."
        if messages[-1]["role"] != "user":
            return "The latest chat message must be a question from the student."
        return None


def main():
    load_local_env()
    port = int(os.environ.get("PORT", "8000"))
    server = ThreadingHTTPServer(("127.0.0.1", port), CompetitiveExamHandler)
    print(f"Competitive Exam is running at http://127.0.0.1:{port}")
    print("Live AI is configured." if os.environ.get("OPENAI_API_KEY", "").strip() else "Live AI is not configured. Add OPENAI_API_KEY to the local .env file, then refresh the dashboard.")
    print("Press Ctrl+C to stop the local server.")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\nStopping Competitive Exam.")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
